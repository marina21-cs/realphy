import React, { useState } from 'react';
import { 
  Settings, HelpCircle, User, Activity, FlaskConical, History, 
  Shield, Link, Orbit, ZoomIn, Focus, Zap, Layers, Droplets, Box,
  Play, Pause, RotateCcw, PenTool, MapPin, BarChart3, Eye, SplitSquareHorizontal, Database, GraduationCap, Terminal, LifeBuoy
} from 'lucide-react';

// --- Types ---
type ViewState = 'story' | 'student' | 'advanced' | 'educator';

// --- Main App Component ---
export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('story');

  return (
    <div className="bg-[#05090B] text-[#dfe3e6] font-body h-screen w-screen overflow-hidden flex flex-col relative selection:bg-[#57ffa8]/30 selection:text-[#57ffa8]">
      {/* Background Textures */}
      <div className="fixed inset-0 grid-overlay z-0 opacity-40"></div>
      <div className="fixed inset-0 scanlines z-10 opacity-50"></div>
      
      {/* Ambient Glow */}
      <div className="fixed inset-0 z-0 pointer-events-none flex items-center justify-center">
        <div className="w-[800px] h-[400px] bg-[#57ffa8]/5 rounded-full blur-[120px]"></div>
      </div>

      <Header currentView={currentView} setView={setCurrentView} />

      <main className="flex-grow relative z-20 overflow-hidden pt-[68px]">
        {currentView === 'story' && <StoryView />}
        {currentView === 'student' && <StudentView />}
        {currentView === 'advanced' && <AdvancedView />}
        {currentView === 'educator' && <EducatorView />}
      </main>
    </div>
  );
}

// --- Header Component ---
function Header({ currentView, setView }: { currentView: ViewState, setView: (v: ViewState) => void }) {
  const navItems: { id: ViewState, label: string }[] = [
    { id: 'story', label: 'Story' },
    { id: 'student', label: 'Student' },
    { id: 'advanced', label: 'Advanced' },
    { id: 'educator', label: 'Educator' },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 flex justify-between items-center px-8 bg-[#101E1C]/80 backdrop-blur-xl h-[68px] border-b border-[#77FFC5]/20 shadow-[0px_24px_48px_rgba(0,0,0,0.4)]">
      <div className="flex items-center gap-8">
        <div className="text-2xl font-extrabold text-[#57FFA8] tracking-widest font-headline uppercase">POLARIZED</div>
        <div className="hidden md:flex items-center gap-6">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`font-headline font-bold tracking-tight px-2 py-1 transition-all duration-300 uppercase text-sm ${
                currentView === item.id 
                  ? 'text-[#57FFA8] border-b-2 border-[#57FFA8]' 
                  : 'text-slate-400 hover:text-[#57FFA8] hover:bg-[#77FFC5]/10'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-4 text-[#57FFA8]">
        <button className="p-2 hover:bg-[#57FFA8]/10 rounded-full transition-colors active:scale-95"><Settings size={20} /></button>
        <button className="p-2 hover:bg-[#57FFA8]/10 rounded-full transition-colors active:scale-95"><HelpCircle size={20} /></button>
        <button className="p-2 hover:bg-[#57FFA8]/10 rounded-full transition-colors active:scale-95"><User size={20} /></button>
      </div>
    </nav>
  );
}

// --- View: Story (Cartographer Log) ---
function StoryView() {
  return (
    <div className="h-full flex flex-col pb-[120px]">
      <div className="flex-grow grid grid-cols-12 gap-6 p-6">
        {/* Left Sidebar */}
        <aside className="col-span-3 glass-panel rounded-xl flex flex-col p-6 overflow-y-auto">
          <header className="mb-6">
            <h2 className="font-headline font-extrabold text-[#57FFA8] text-lg leading-tight uppercase tracking-tighter">Cartographer Log</h2>
            <div className="w-8 h-1 bg-[#57FFA8] mt-2"></div>
          </header>
          <div className="space-y-6 text-sm text-[#bacbbd] font-body leading-relaxed">
            <p className="border-l-2 border-[#57FFA8]/50 pl-4 italic opacity-80">
              "The vacuum between the plates is absolute. Only the potential remains—a dormant tension waiting for the trigger."
            </p>
            <p>
              Simulation Act I: The Parallel Construct. We are observing the fundamental behavior of energy storage in a state of pure isolation. No dielectric presence detected.
            </p>
            <div className="p-4 bg-[#77FFC5]/5 border border-[#77FFC5]/20 rounded-lg">
              <span className="font-mono text-[10px] text-[#57FFA8] block mb-2 uppercase tracking-widest">DATA_STREAM: 0x442A</span>
              <p className="font-mono text-xs text-[#50e7ff] leading-relaxed">Awaiting voltage differential input to stabilize field geometry.</p>
            </div>
          </div>
        </aside>

        {/* Center Viewport */}
        <section className="col-span-6 relative flex items-center justify-center">
          <div className="w-full h-full glass-panel rounded-xl overflow-hidden relative flex items-center justify-center">
            <div className="absolute inset-0 bg-gradient-to-tr from-[#0f1416] to-[#05090B] opacity-80"></div>
            
            {/* Abstract Parallel Plates */}
            <div className="relative w-3/4 h-1/2 flex justify-between items-center group">
              {/* Left Plate (+) */}
              <div className="w-8 h-full bg-gradient-to-b from-[#57FFA8]/30 to-[#57FFA8]/80 border-l-2 border-[#57FFA8] shadow-[0_0_40px_rgba(87,255,168,0.3)] flex flex-col justify-around py-8 items-center rounded-l-sm">
                <span className="text-[#002110] font-mono font-bold">+</span>
                <span className="text-[#002110] font-mono font-bold">+</span>
                <span className="text-[#002110] font-mono font-bold">+</span>
              </div>
              
              {/* Field Lines */}
              <div className="flex-grow h-full flex flex-col justify-around px-4 opacity-60">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-[2px] w-full bg-gradient-to-r from-[#50e7ff]/80 via-[#50e7ff]/30 to-transparent shadow-[0_0_8px_rgba(80,231,255,0.5)]"></div>
                ))}
              </div>
              
              {/* Right Plate (-) */}
              <div className="w-8 h-full bg-gradient-to-b from-slate-800 to-slate-950 border-r-2 border-slate-600 flex flex-col justify-around py-8 items-center rounded-r-sm shadow-[-10px_0_30px_rgba(0,0,0,0.5)]">
                <span className="text-slate-500 font-mono font-bold">-</span>
                <span className="text-slate-500 font-mono font-bold">-</span>
                <span className="text-slate-500 font-mono font-bold">-</span>
              </div>
            </div>

            {/* Viewport Controls */}
            <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-4">
              <button className="flex items-center gap-2 px-5 py-2 glass-panel rounded-full text-[10px] font-headline font-bold text-[#57FFA8] hover:bg-[#77FFC5]/20 transition-all uppercase tracking-widest">
                <Orbit size={14} /> Orbit
              </button>
              <button className="flex items-center gap-2 px-5 py-2 glass-panel rounded-full text-[10px] font-headline font-bold text-[#57FFA8] hover:bg-[#77FFC5]/20 transition-all uppercase tracking-widest">
                <ZoomIn size={14} /> Zoom
              </button>
              <button className="flex items-center gap-2 px-5 py-2 glass-panel rounded-full text-[10px] font-headline font-bold text-[#57FFA8] hover:bg-[#77FFC5]/20 transition-all uppercase tracking-widest">
                <Focus size={14} /> Recenter
              </button>
            </div>

            {/* Equation HUD */}
            <div className="absolute top-6 right-6 p-5 glass-panel rounded-xl max-w-[220px] border-[#50e7ff]/30">
              <span className="font-mono text-[10px] text-[#50e7ff] opacity-80 block mb-3 uppercase tracking-widest">Capacitance EQ</span>
              <div className="font-mono text-sm text-white">C = ε₀ · (A / d)</div>
              <div className="mt-4 border-t border-[#50e7ff]/20 pt-3 font-mono text-[10px] text-slate-400">
                ε₀: 8.854e-12 F/m
              </div>
            </div>
          </div>
        </section>

        {/* Right Sidebar */}
        <aside className="col-span-3 glass-panel rounded-xl flex flex-col p-6">
          <header className="mb-10">
            <h2 className="font-headline font-extrabold text-[#50e7ff] text-lg leading-tight uppercase tracking-widest">Instrument Tuning</h2>
          </header>
          
          <div className="space-y-10 flex-grow">
            <SliderControl label="Area (A)" value="1.45" unit="cm²" progress={65} />
            <SliderControl label="Separation (d)" value="0.82" unit="mm" progress={30} />
            <SliderControl label="Voltage (V)" value="12.50" unit="V" progress={45} />
          </div>

          <button className="mt-auto w-full py-4 bg-[#57FFA8] text-[#002110] font-headline font-extrabold uppercase tracking-widest text-xs rounded-lg hover:shadow-[0_0_25px_rgba(87,255,168,0.5)] transition-all flex items-center justify-center gap-2 active:scale-95">
            <Zap size={16} fill="currentColor" /> Trigger Discharge
          </button>
        </aside>
      </div>

      {/* Bottom Metric Strip */}
      <footer className="fixed bottom-0 w-full z-50 flex flex-row items-center justify-around px-12 bg-[#0a0f11]/90 backdrop-blur-xl h-[120px] border-t border-[#77FFC5]/20 shadow-[0_-20px_40px_rgba(0,0,0,0.5)]">
        <div className="flex gap-16 items-center flex-grow justify-center">
          <MetricCard label="Capacitance (C)" value="1.565" unit="pF" color="bg-[#57FFA8]" />
          <MetricCard label="Charge (Q)" value="19.56" unit="pC" color="bg-[#50e7ff]" />
          <MetricCard label="Energy (U)" value="122.3" unit="pJ" color="bg-[#57FFA8]" />
          <MetricCard label="E-Field (E)" value="15.24" unit="kV/m" color="bg-[#ffb4ab]" />
        </div>
        <div className="flex flex-col items-end gap-2 border-l border-[#77FFC5]/20 pl-10 h-1/2 justify-center">
          <div className="font-mono text-[10px] uppercase tracking-widest text-[#57FFA8]">Simulation Status: Active</div>
          <div className="font-mono text-[10px] uppercase tracking-widest text-slate-500">Connection: High-Fidelity</div>
          <div className="font-mono text-[9px] text-slate-600 mt-2">© 2026 PRECISION INSTRUMENTATION</div>
        </div>
      </footer>
    </div>
  );
}

// --- View: Student (Act II) ---
function StudentView() {
  return (
    <div className="h-full flex flex-col">
      <div className="flex-grow flex">
        {/* Left Material Rail */}
        <aside className="w-72 glass-panel border-y-0 border-l-0 border-r border-[#77FFC5]/20 flex flex-col">
          <div className="p-6 border-b border-[#77FFC5]/10">
            <h2 className="font-body text-[10px] uppercase tracking-widest text-slate-500 mb-2">Material Library</h2>
            <p className="font-headline text-lg font-bold text-[#57FFA8] uppercase tracking-tight">Act II Selection</p>
          </div>
          <nav className="flex-1 py-6 px-4 space-y-3 overflow-y-auto">
            <MaterialItem icon={<Box size={18} />} label="Vacuum" active />
            <MaterialItem icon={<Droplets size={18} />} label="Water" />
            <MaterialItem icon={<Layers size={18} />} label="Borosilicate" />
            <MaterialItem icon={<FlaskConical size={18} />} label="Barium Titanate" />
          </nav>
          <div className="p-6 mt-auto border-t border-[#77FFC5]/10">
            <button className="w-full py-4 rounded-lg bg-[#57FFA8] text-[#002110] font-headline font-bold text-[10px] uppercase tracking-widest hover:shadow-[0_0_20px_rgba(87,255,168,0.4)] transition-all">
              Initialize Material
            </button>
          </div>
        </aside>

        {/* Center Viewport */}
        <section className="flex-grow relative flex items-center justify-center p-12">
          {/* Dielectric Slab Visualization */}
          <div className="w-full max-w-4xl h-[400px] glass-panel rounded-2xl shadow-2xl flex items-center overflow-hidden relative">
            <div className="absolute inset-0 flex">
              <div className="w-1/2 h-full bg-gradient-to-r from-[#50e7ff]/10 to-transparent border-r border-dashed border-slate-600 flex items-center justify-around px-12">
                <div className="space-y-6 opacity-50">
                  <div className="w-32 h-[2px] bg-[#50e7ff] shadow-[0_0_10px_rgba(80,231,255,0.6)]"></div>
                  <div className="w-32 h-[2px] bg-[#50e7ff] shadow-[0_0_10px_rgba(80,231,255,0.6)]"></div>
                  <div className="w-32 h-[2px] bg-[#50e7ff] shadow-[0_0_10px_rgba(80,231,255,0.6)]"></div>
                </div>
              </div>
              <div className="w-1/2 h-full bg-gradient-to-l from-[#f5bd65]/10 to-transparent flex items-center justify-around px-12">
                <div className="space-y-6">
                  <div className="w-32 h-[2px] bg-[#f5bd65] shadow-[0_0_10px_rgba(245,189,101,0.6)]"></div>
                  <div className="w-32 h-[2px] bg-[#f5bd65] shadow-[0_0_10px_rgba(245,189,101,0.6)]"></div>
                  <div className="w-32 h-[2px] bg-[#f5bd65] shadow-[0_0_10px_rgba(245,189,101,0.6)]"></div>
                </div>
              </div>
            </div>
            
            <div className="absolute top-6 left-6 font-mono text-[10px] text-[#50e7ff] tracking-widest uppercase">Input: 12.4 kV/m</div>
            <div className="absolute top-6 right-6 font-mono text-[10px] text-[#f5bd65] tracking-widest uppercase">Induced: 8.2 pC/m²</div>
            <div className="absolute bottom-6 left-6 font-mono text-[10px] text-slate-500 tracking-widest uppercase">Phase: Liquid Crystal</div>
            <div className="absolute bottom-6 right-6 font-mono text-[10px] text-slate-500 tracking-widest uppercase">Factor: 0.992</div>
          </div>

          {/* Floating Controls Right */}
          <div className="absolute top-12 right-12 w-80 glass-panel rounded-xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-8">
              <span className="font-headline font-bold text-[10px] uppercase tracking-widest text-[#57FFA8]">Field Parameters</span>
              <span className="w-2 h-2 rounded-full bg-[#ffb4ab] animate-pulse"></span>
            </div>
            <div className="space-y-8">
              <SliderControl label="POTENTIAL (Φ)" value="42.8" unit="MV" progress={42} color="bg-[#50e7ff]" />
              <SliderControl label="DIPOLE ALIGNMENT" value="88.5" unit="%" progress={88} color="bg-[#f5bd65]" />
              
              <div className="pt-6 border-t border-[#77FFC5]/20 grid grid-cols-2 gap-4">
                <button className="p-4 glass-panel rounded-lg flex flex-col items-center justify-center gap-3 hover:bg-[#57FFA8]/10 transition-all group">
                  <Play size={20} className="text-[#50e7ff] group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[9px] uppercase tracking-widest text-slate-300">Animate</span>
                </button>
                <button className="p-4 glass-panel rounded-lg flex flex-col items-center justify-center gap-3 hover:bg-[#57FFA8]/10 transition-all group">
                  <Layers size={20} className="text-[#f5bd65] group-hover:scale-110 transition-transform" />
                  <span className="font-mono text-[9px] uppercase tracking-widest text-slate-300">Grid</span>
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

// --- View: Advanced (Act III) ---
function AdvancedView() {
  return (
    <div className="h-full p-8 grid grid-cols-12 gap-8 pb-[100px]">
      {/* Title Area */}
      <div className="col-span-12 mb-4">
        <h1 className="font-headline text-5xl font-extrabold text-[#dfe3e6] uppercase tracking-tighter">
          OBSERVATIONAL <span className="text-[#57FFA8]">DECAY</span>
        </h1>
        <p className="font-mono text-xs text-slate-500 mt-3 tracking-widest uppercase">Sequence: 003_ALPHA // Capacitor Discharge State</p>
      </div>

      {/* Left Panel */}
      <div className="col-span-3 glass-panel rounded-2xl p-8 flex flex-col">
        <div className="flex items-center gap-3 mb-10">
          <span className="w-2 h-2 rounded-full bg-[#57FFA8] animate-pulse"></span>
          <span className="font-headline font-bold text-sm tracking-widest uppercase text-[#57FFA8]">Instrumentation</span>
        </div>
        
        <div className="space-y-10 flex-grow">
          <DataReadout label="INITIAL_POTENTIAL (V0)" value="480.00" unit="VOLTS" />
          <DataReadout label="TOTAL_CAPACITANCE (C)" value="220.50" unit="μF" />
          <DataReadout label="SYSTEM_RESISTANCE (R)" value="1.25" unit="kΩ" />
        </div>

        <button className="mt-8 w-full py-5 bg-[#57FFA8] text-[#002110] font-headline font-bold text-xs uppercase tracking-widest rounded-xl shadow-[0_0_30px_rgba(87,255,168,0.3)] hover:scale-[1.02] active:scale-95 transition-all">
          Initiate Discharge
        </button>
      </div>

      {/* Center Visual */}
      <div className="col-span-6 relative flex items-center justify-center">
        <div className="relative group">
          <div className="w-40 h-80 bg-[#1b2023] border border-[#57FFA8]/30 rounded-2xl relative overflow-hidden shadow-[0_0_50px_rgba(87,255,168,0.1)]">
            <div className="absolute bottom-0 w-full bg-[#57FFA8]/20 h-[65%] border-t border-[#57FFA8]/50"></div>
            <div className="absolute inset-0 scanlines opacity-50"></div>
          </div>
          <div className="absolute inset-0 -m-12 bg-[#57FFA8]/10 blur-[80px] rounded-full group-hover:bg-[#57FFA8]/20 transition-all duration-700"></div>
          
          {/* Floating Tag */}
          <div className="absolute -right-56 top-1/4 glass-panel p-4 rounded-xl border-l-4 border-l-[#57FFA8] flex gap-4 items-center">
            <Zap className="text-[#57FFA8]" size={24} />
            <div>
              <p className="font-mono text-[10px] text-slate-400 uppercase tracking-widest mb-1">Active_Flux</p>
              <p className="font-mono text-xl text-[#57FFA8]">12.44 kJ/s</p>
            </div>
          </div>
        </div>
        
        {/* Crosshairs */}
        <div className="absolute w-full h-px bg-gradient-to-r from-transparent via-[#57FFA8]/30 to-transparent top-1/2"></div>
        <div className="absolute h-full w-px bg-gradient-to-b from-transparent via-[#57FFA8]/30 to-transparent left-1/2"></div>
      </div>

      {/* Right Panel */}
      <div className="col-span-3 glass-panel rounded-2xl p-8 flex flex-col">
        <div className="flex items-center justify-between mb-8">
          <span className="font-headline font-bold text-xs tracking-widest text-slate-400 uppercase">Live Metrics</span>
          <span className="text-[10px] font-mono text-[#ffb4ab] flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ffb4ab] animate-pulse"></span> LIVE
          </span>
        </div>

        {/* Chart Mockup */}
        <div className="h-48 w-full border-l border-b border-slate-700 relative mb-10">
          <div className="absolute bottom-1/4 w-full h-px border-t border-dashed border-slate-700/50"></div>
          <div className="absolute bottom-2/4 w-full h-px border-t border-dashed border-slate-700/50"></div>
          <div className="absolute bottom-3/4 w-full h-px border-t border-dashed border-slate-700/50"></div>
          <svg className="absolute inset-0 w-full h-full overflow-visible" preserveAspectRatio="none">
            <path d="M 0 10 Q 150 10, 300 180" fill="none" stroke="#57ffa8" strokeWidth="3"></path>
            <path d="M 0 50 Q 150 50, 300 185" fill="none" stroke="#50e7ff" strokeWidth="2" strokeDasharray="4 4" opacity="0.6"></path>
          </svg>
        </div>

        <div className="space-y-4">
          <MetricRow label="Stability_Index" value="98.42%" color="text-[#57FFA8]" />
          <MetricRow label="Thermal_Load" value="314.1 K" color="text-[#50e7ff]" />
          <MetricRow label="Entropy_Rate" value="0.0024 σ" color="text-[#57FFA8]" />
        </div>
      </div>

      {/* Bottom Nav */}
      <footer className="fixed bottom-0 left-0 w-full z-50 grid grid-cols-2 bg-[#0a0f11]/90 backdrop-blur-xl divide-x divide-[#77FFC5]/20 h-24 border-t border-[#77FFC5]/20">
        <button className="flex flex-col items-center justify-center bg-[#57FFA8]/10 text-[#57FFA8] hover:bg-[#57FFA8]/20 transition-all">
          <Activity size={20} className="mb-2" />
          <span className="font-mono text-[10px] uppercase tracking-widest">Live Equations</span>
        </button>
        <button className="flex flex-col items-center justify-center text-slate-500 hover:text-[#57FFA8] hover:bg-[#57FFA8]/5 transition-all">
          <BarChart3 size={20} className="mb-2" />
          <span className="font-mono text-[10px] uppercase tracking-widest">Decay Charts</span>
        </button>
      </footer>
    </div>
  );
}

// --- View: Educator ---
function EducatorView() {
  return (
    <div className="h-full flex">
      {/* Left Sidebar */}
      <aside className="w-72 bg-[#0a0f11] border-r border-[#77FFC5]/10 flex flex-col z-30">
        <div className="p-8 border-b border-[#77FFC5]/10">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#1b2023] border border-slate-700 flex items-center justify-center">
              <Shield className="text-[#57FFA8]" size={24} />
            </div>
            <div>
              <div className="font-mono font-bold text-xs text-white uppercase tracking-widest">System_Alpha</div>
              <div className="font-mono text-[9px] text-[#57FFA8] mt-1 uppercase tracking-widest">Educator Mode Active</div>
            </div>
          </div>
        </div>
        <nav className="flex-1 py-4">
          <EducatorNavItem icon={<Eye size={18} />} label="Observer" />
          <EducatorNavItem icon={<SplitSquareHorizontal size={18} />} label="Split View" />
          <EducatorNavItem icon={<Database size={18} />} label="Data Stream" />
          <EducatorNavItem icon={<GraduationCap size={18} />} label="Educator Hub" active />
          <EducatorNavItem icon={<History size={18} />} label="History" />
        </nav>
        <div className="p-6 border-t border-[#77FFC5]/10 space-y-2">
          <EducatorNavItem icon={<LifeBuoy size={16} />} label="Support" small />
          <EducatorNavItem icon={<Terminal size={16} />} label="Terminal" small />
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-grow p-10 overflow-y-auto">
        <header className="mb-10">
          <h1 className="font-headline font-extrabold text-4xl tracking-tighter text-white uppercase">POLARIZED - Educator Mode</h1>
          <p className="font-mono text-[#57FFA8] text-[10px] mt-3 flex items-center gap-2 tracking-widest uppercase">
            <span className="w-2 h-2 bg-[#57FFA8] rounded-full animate-pulse"></span>
            Live Linked Session: #ED-4492-X
          </p>
        </header>

        <div className="grid grid-cols-12 gap-8">
          {/* Left Col */}
          <div className="col-span-4 space-y-8">
            {/* Control Locks */}
            <section className="glass-panel p-8 rounded-2xl">
              <div className="flex items-center justify-between mb-8">
                <h2 className="font-headline font-bold text-sm uppercase tracking-widest text-white">Control Locks</h2>
                <Shield className="text-[#57FFA8]" size={20} />
              </div>
              <div className="space-y-4">
                <ToggleRow title="Input Overrides" desc="Lock all student axis-controllers" active />
                <ToggleRow title="Physics Constants" desc="Prevent deviation from target G-force" />
                <ToggleRow title="Annotation View" desc="Force overlay visibility for all peers" active />
              </div>
              <button className="w-full mt-8 py-4 bg-[#57FFA8] text-[#002110] font-headline font-bold uppercase tracking-widest text-[10px] rounded-lg hover:shadow-[0_0_20px_rgba(87,255,168,0.3)] transition-all">
                Apply Master Lockouts
              </button>
            </section>

            {/* URL Builder */}
            <section className="glass-panel p-8 rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h2 className="font-headline font-bold text-sm uppercase tracking-widest text-white">URL State Builder</h2>
                <Link className="text-[#50e7ff]" size={20} />
              </div>
              <div className="bg-[#0a0f11] p-5 rounded-lg border border-slate-800 mb-6">
                <code className="font-mono text-[10px] text-[#50e7ff] break-all leading-relaxed">
                  polarized://sim/alpha?v=1.4&t=442&locks=true&annot=visible&overlay=edu_active&grid=1x1
                </code>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <button className="py-3 border border-slate-700 rounded font-headline font-bold text-[9px] uppercase tracking-widest text-slate-300 hover:bg-white/5 transition-colors">Copy State</button>
                <button className="py-3 border border-slate-700 rounded font-headline font-bold text-[9px] uppercase tracking-widest text-slate-300 hover:bg-white/5 transition-colors">Generate QR</button>
              </div>
            </section>
          </div>

          {/* Right Col */}
          <div className="col-span-8 flex flex-col gap-8">
            {/* Tools Row */}
            <div className="grid grid-cols-3 gap-6">
              <ToolCard icon={<PenTool size={24} className="text-[#57FFA8]" />} title="Freeform Vector" desc="Draw directly into the 3D space with persistence." id="TOOL_01" />
              <ToolCard icon={<MapPin size={24} className="text-[#50e7ff]" />} title="Spatial Callout" desc="Pin data labels to specific simulation coordinates." id="TOOL_02" />
              <ToolCard icon={<Activity size={24} className="text-[#f5bd65]" />} title="Metric Probe" desc="Sample local simulation values in real-time." id="TOOL_03" />
            </div>

            {/* Viewport Mock */}
            <div className="glass-panel flex-grow rounded-2xl relative flex items-center justify-center min-h-[400px] overflow-hidden">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(87,255,168,0.05)_1px,transparent_1px)] bg-[length:24px_24px]"></div>
              
              <div className="absolute top-8 left-8 font-mono text-[10px] space-y-2">
                <div className="flex gap-4"><span className="text-slate-500 w-8">LAT:</span> <span className="text-white">42.3601° N</span></div>
                <div className="flex gap-4"><span className="text-slate-500 w-8">LNG:</span> <span className="text-white">71.0589° W</span></div>
                <div className="flex gap-4"><span className="text-slate-500 w-8">ALT:</span> <span className="text-[#57FFA8]">12,400M</span></div>
              </div>

              <div className="absolute top-8 right-8">
                <div className="flex items-center gap-2 px-4 py-2 bg-[#93000a]/30 rounded-full border border-[#ffb4ab]/30">
                  <span className="w-2 h-2 bg-[#ffb4ab] rounded-full animate-pulse"></span>
                  <span className="font-mono text-[9px] text-[#ffb4ab] tracking-widest uppercase">Recording_Buffer</span>
                </div>
              </div>

              <div className="text-center z-10">
                <div className="w-48 h-48 border border-dashed border-[#57FFA8]/30 rounded-full mx-auto mb-8 flex items-center justify-center relative">
                  <div className="absolute inset-0 border border-[#57FFA8]/10 rounded-full animate-[spin_10s_linear_infinite]"></div>
                  <Orbit size={48} className="text-[#57FFA8]/20" />
                </div>
                <p className="font-headline font-light tracking-[0.3em] text-slate-500 text-[10px] uppercase mb-3">Viewport Stream Primary</p>
                <h3 className="font-mono text-xl text-[#57FFA8]">Awaiting State Interaction...</h3>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// --- Helper Components ---

function MetricCard({ label, value, unit, color }: { label: string, value: string, unit: string, color: string }) {
  return (
    <div className="flex flex-col">
      <div className="flex items-center gap-3 mb-2">
        <span className="font-mono text-[10px] uppercase tracking-widest text-slate-500">{label}</span>
        <div className="w-10 h-[1px] bg-slate-700"></div>
      </div>
      <div className={`font-mono text-3xl font-bold ${color.replace('bg-', 'text-')}`}>
        {value} <span className="text-sm font-normal opacity-80">{unit}</span>
      </div>
      <div className={`h-1 w-full mt-3 bg-gradient-to-r from-transparent via-${color.replace('bg-', '')}/30 to-transparent`}></div>
    </div>
  );
}

function SliderControl({ label, value, unit, progress, color = "bg-[#50e7ff]" }: { label: string, value: string, unit: string, progress: number, color?: string }) {
  return (
    <div className="space-y-3">
      <div className="flex justify-between items-end">
        <label className="font-headline text-[10px] font-bold text-slate-400 tracking-widest uppercase">{label}</label>
        <span className="font-mono text-[#57FFA8] text-sm">{value} <span className="text-[10px]">{unit}</span></span>
      </div>
      <div className="relative h-1 bg-[#1b2023] rounded-full">
        <div className={`absolute top-0 left-0 h-full ${color} rounded-full`} style={{ width: `${progress}%` }}></div>
        <div className={`absolute top-1/2 -translate-y-1/2 w-3 h-3 ${color} rounded-sm rotate-45 border-2 border-[#05090B] shadow-[0_0_10px_currentColor]`} style={{ left: `${progress}%` }}></div>
      </div>
    </div>
  );
}

function MaterialItem({ icon, label, active }: { icon: React.ReactNode, label: string, active?: boolean }) {
  return (
    <button className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all duration-300 ${
      active 
        ? 'bg-[#101E1C] text-[#57FFA8] border-l-4 border-[#57FFA8]' 
        : 'text-slate-500 hover:text-slate-300 hover:bg-[#101E1C]/50 hover:translate-x-1'
    }`}>
      {icon}
      <span className="font-body text-sm tracking-tight">{label}</span>
    </button>
  );
}

function DataReadout({ label, value, unit }: { label: string, value: string, unit: string }) {
  return (
    <div>
      <label className="font-mono text-[9px] text-slate-500 block mb-3 uppercase tracking-widest">{label}</label>
      <div className="flex justify-between items-end border-b border-slate-800 pb-2">
        <span className="font-mono text-4xl text-[#57FFA8]">{value}</span>
        <span className="font-mono text-[10px] text-slate-500 pb-1">{unit}</span>
      </div>
    </div>
  );
}

function MetricRow({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="flex justify-between items-center p-4 bg-[#101E1C]/50 rounded-xl border border-[#77FFC5]/5">
      <span className="font-mono text-[10px] text-slate-400 uppercase tracking-widest">{label}</span>
      <span className={`font-mono text-sm ${color}`}>{value}</span>
    </div>
  );
}

function EducatorNavItem({ icon, label, active, small }: { icon: React.ReactNode, label: string, active?: boolean, small?: boolean }) {
  return (
    <a href="#" className={`flex items-center gap-4 px-8 py-4 transition-all duration-300 ${
      active 
        ? 'bg-[#57FFA8]/10 text-[#57FFA8] border-r-2 border-[#57FFA8]' 
        : 'text-slate-500 hover:bg-[#101E1C] hover:translate-x-1'
    } ${small ? 'py-3 text-xs' : 'text-sm'}`}>
      {icon}
      <span className="font-mono uppercase tracking-widest">{label}</span>
    </a>
  );
}

function ToggleRow({ title, desc, active }: { title: string, desc: string, active?: boolean }) {
  return (
    <label className="flex items-center justify-between p-4 bg-[#101E1C]/40 rounded-xl hover:bg-[#101E1C] transition-colors cursor-pointer border border-transparent hover:border-[#77FFC5]/10">
      <div className="flex flex-col gap-1">
        <span className="font-headline font-bold text-xs text-white uppercase tracking-widest">{title}</span>
        <span className="font-mono text-[9px] text-slate-500">{desc}</span>
      </div>
      <div className={`w-10 h-5 rounded-full relative transition-colors ${active ? 'bg-[#57FFA8]/20 border border-[#57FFA8]' : 'bg-slate-800 border border-slate-700'}`}>
        <div className={`absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full transition-all ${active ? 'bg-[#57FFA8] right-1 shadow-[0_0_10px_#57FFA8]' : 'bg-slate-500 left-1'}`}></div>
      </div>
    </label>
  );
}

function ToolCard({ icon, title, desc, id }: { icon: React.ReactNode, title: string, desc: string, id: string }) {
  return (
    <div className="glass-panel p-6 rounded-2xl flex flex-col gap-4 group hover:bg-[#57FFA8]/5 transition-all cursor-pointer border-transparent hover:border-[#57FFA8]/30">
      <div className="flex items-center justify-between">
        {icon}
        <span className="font-mono text-[9px] text-slate-600 tracking-widest">{id}</span>
      </div>
      <div className="font-headline font-bold text-sm text-white uppercase tracking-widest mt-2">{title}</div>
      <p className="font-body text-[11px] text-slate-400 leading-relaxed">{desc}</p>
    </div>
  );
}
